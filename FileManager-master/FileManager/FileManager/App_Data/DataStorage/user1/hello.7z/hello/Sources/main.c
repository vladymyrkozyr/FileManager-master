#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */
#include "mc13213.h"

#define LE PTBD_PTBD0
#define RS PTBD_PTBD1
#define E PTBD_PTBD2
#define RW PTBD_PTBD3
#define BF PTBD_PTBD7

#define LED_0 PTDD_PTDD4
#define LED_1 PTDD_PTDD5
#define LED_2 PTDD_PTDD6
#define LED_3 PTDD_PTDD7

void delay(int count) {
	long int i;
	for (i = 0; i < count * 100; i++) 
		__RESET_WATCHDOG();
}
void waitBF() {
	int B = 0;
	do {
		RS = 0;
		RW = 1;
		E = 1;
		PTBDD_PTBDD7 = 0;
		B = BF;
		PTBDD_PTBDD7 = 1;
		E = 0;
		RS = 0;
		RW = 1;
		E = 1;
		B = B + B; // waiting
		E = 0;
		__RESET_WATCHDOG();
	} while(B > 1);
}
char L = 0b00001111;
char H = 0b11110000;
void write4bit(char b, int rs) {
	RS = rs;
	RW = 0;
	E = 1;
	PTBD = (b & H) | (PTBD & L);
	E = 0;
}
void writeChar(char chr) {
	waitBF();
	write4bit(chr & H, 1);
	write4bit((chr & L) << 4, 1);
}
void writeInstr(char instr) {
	waitBF();
	write4bit(instr & H, 0);
	write4bit((instr & L) << 4, 0);
}
void writePositionedChar(char chr, int pos) {
	waitBF();
	writeInstr(0x80 + (pos - 1));
	writeChar(chr);
}
void initDisplay() {
	PTBDD = 0xFF;
	LE = 0;
	delay(10);
	
	// 4-bit interface
	write4bit(0x20, 0);
	delay(10);
	// 1 line & font
	writeInstr(0x20);
	// cursor
	writeInstr(0x08);
	// clear
	writeInstr(0x01);
	// entry mode
	writeInstr(0x06);
	// cursor enable
	writeInstr(0x0C);
}

void initButtons() {
	PTDDD = 0b11110000;
	PTDD = 0b11110000;
	PTAPE = 0b00111100;
		
	PTCDD = 0b00010000;
}

int state = 1;
// 1 - enter first number
// 2 - enter sign
// 3 - enter second number
// 4 - result
int firstNumState = 1; //  1 - 5
int signState = 1; // 1 - 4
int secondNumState = 1; //  1 - 5
int firstButtonPressed = 0;
int secondButtonPressed = 0;
int thirdButtonPressed = 0;

int i = 0;
int firstSwitched[4] = {0,0,0,0};
int lastPress[4] = {0,0,0,0};
void checkButton(byte button, int n) {
	if (!button)
	{
		if(!lastPress[n]) {
			lastPress[n] = i;
			firstSwitched[n] = 0;
		}
		if(i - lastPress[n] > 100 && !firstSwitched[n]) {
			firstSwitched[n] = 1;
			switch(n) { // number of button
				case 1:
					firstButtonPressed = 1; // digit increment
					break;
				case 2:
					secondButtonPressed = 1; // digit transition
					switch(state) {
						case 1: // transitions between first number digits
							firstNumState++;
							break;
						case 3: // transitions between second number digits
							secondNumState++;
							break;
					}
					break;
				case 3: // global state change
					state++;
					thirdButtonPressed = 1;
					if(state == 5) {
						state = 2;
					}
					break;
				case 4:
					break;
			}
		}
	}
	if(button) {
		lastPress[n] = 0;
	}
}

void controlState() {
	checkButton(_PTAD.Bits.PTAD2, 1);
	checkButton(_PTAD.Bits.PTAD3, 2);
	checkButton(_PTAD.Bits.PTAD4, 3);
	checkButton(_PTAD.Bits.PTAD5, 4);
	i++;
}

int counter1 = 1;
void displayFirstNum() {
	if (firstButtonPressed) {
		firstButtonPressed = 0;
		if(firstNumState > 6) {
			return;
		}
		if(firstNumState < 6) {
			if(counter1 == 11) {
				counter1 = 1;
			}
			writePositionedChar((counter1 - 1) + '0', 7 - firstNumState);
		}
		if(firstNumState == 6) {
			if(counter1 == 2) {
				counter1 = 0;
			}
			writePositionedChar(counter1 == 0 ? '+' : '-', 1);
		}
		counter1++;
	}
}

int firstMultiplier = 1;
int firstNumber = 1;
void readFirstNum() {
	if(secondButtonPressed) {
		secondButtonPressed = 0;
		if(firstNumState > 6) {
			return;
		}
		if(firstNumState < 6) {
			if(firstNumState == 2) firstNumber = 0; // kostil' 
			firstNumber = firstNumber + firstMultiplier * (counter1 - 2);
			counter1 = 1;
			
			firstMultiplier = firstMultiplier * 10;
		}
		if(firstNumState == 6) {
			firstNumber = counter1 == 0 ? firstNumber : -firstNumber;
		}
	}
}

int signNum = 4;
char sign = '+';
void displaySign() {
	if (firstButtonPressed) {
		signNum++;
		if(signNum == 5) {
			signNum = 1;
		}
		switch(signNum) {
			case 1:
				sign = '-';
				break;
			case 2:
				sign = '*';
				break;
			case 3:
				sign = '/';
				break;
			case 4:
				sign = '+';
				break;
		}
		firstButtonPressed = 0;
	}
	writePositionedChar(sign, 8);
}

int counter2 = 1; // 0-9
void displaySecondNum() {
	if (firstButtonPressed) {
		firstButtonPressed = 0;
		if(secondNumState > 6) {
			return;
		}
		if(secondNumState < 6) { // max number contains 5 digits
			if(counter2 == 11) {
				counter2 = 1;
			}
			writePositionedChar((counter2 - 1) + '0', 16 - secondNumState);
		} 
		if(secondNumState == 6) { // sign
			if(counter2 == 2) {
				counter2 = 0;
			}
			writePositionedChar(counter2 == 0 ? '+' : '-', 10);
		}
		counter2++;
	}
}

int secondMultiplier = 1;
int secondNumber = 1;
void readSecondNum() {
	if(secondButtonPressed) {
		secondButtonPressed = 0;
		if(secondNumState > 6) {
			return;
		}
		if(secondNumState < 6) {
			if(secondNumState == 2) secondNumber = 0; // kostil'
			secondNumber = secondNumber + secondMultiplier * (counter2 - 2);
			counter2 = 1;
			
			secondMultiplier = secondMultiplier * 10;
		}
		if(secondNumState == 6) {
			secondNumber = counter2 == 0 ? secondNumber : -secondNumber;
		}
	}
}

void writeCriticalErr() {
	char err[] = "Error!";
	int length = sizeof(err);
	int j;
	for(j = 0; j < length; j++) {
		writePositionedChar(err[j], j + 5);
	}
	state = 999;
}

int result = 0;
void displayResult() {
	if(thirdButtonPressed) {
		int tmpResult, digit, position;
		// clear
		writeInstr(0x01);
		counter1 = 1;
		counter2 = 1;
		firstMultiplier = 1;
		secondMultiplier = 1;
		
		firstNumState = 1;
		signState = 1;
		secondNumState = 1;
		
		// evaluating
		switch(signNum) {
			case 1:
				result = firstNumber - secondNumber;
				break;
			case 2:
				result = firstNumber * secondNumber;
				break;
			case 3:
				if(secondNumber == 0) {
					writeCriticalErr();
					return;
				}
				result = firstNumber / secondNumber;
				break;
			case 4:
				result = firstNumber + secondNumber;
				break;
		}
		
		// cleanup
		sign = '+';
		signNum = 4;
		firstNumber = result;
		secondNumber = 0;
		
		// printing
		position = 6;
		tmpResult = result;
		if(tmpResult < 0) {
			writePositionedChar('-', 1);
			tmpResult = -tmpResult;
		}
		if(tmpResult == 0) {
			writePositionedChar('0', position);
		}
		while(position != 1) {
			digit = tmpResult % 10;
			writePositionedChar(digit + '0', position);
			tmpResult = tmpResult / 10;
			position--;
		}
		
		thirdButtonPressed = 0;
	}
}

void controlDisplay() {
	switch(state) {
		case 1:
			displayFirstNum();
			readFirstNum();
			break;
		case 2:
			displaySign();
			break;
		case 3:
			displaySecondNum();
			readSecondNum();
			break;
		case 4:
			displayResult();
			break;
	}
}

void main(void) {
	initDisplay();
	initButtons();
	for(;;) {
		__RESET_WATCHDOG();
		controlState();
		controlDisplay();
	}
}
